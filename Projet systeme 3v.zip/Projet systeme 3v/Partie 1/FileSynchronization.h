struct File {
   char  name[50];
   char  clientname[50];
   char  dateReception[100];
} file;  
