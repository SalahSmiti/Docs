Add md5 for client
