package enstabretagne.BasicMovement.SimEntity.Artefact;

import enstabretagne.base.logger.Logger;
import enstabretagne.base.logger.ToRecord;
import enstabretagne.monitor.interfaces.IMovable;
import enstabretagne.simulation.components.IEntity;
import enstabretagne.simulation.components.data.SimFeatures;
import enstabretagne.simulation.components.data.SimInitParameters;
import enstabretagne.simulation.components.implementation.SimEntity;
import enstabretagne.BasicMovement.SimEntity.MouvementSequenceur.EntityMouvementSequenceur;
import enstabretagne.BasicMovement.SimEntity.MouvementSequenceur.EntityMouvementSequenceur_Exemple;
import enstabretagne.BasicMovement.SimEntity.Artefact.Representation3D.EntityArtefact3DRepresentationInterface;
import javafx.geometry.Point3D;
import javafx.scene.paint.Color;

@ToRecord(name="Artefact")
public class EntityArtefact extends SimEntity implements IMovable,EntityArtefact3DRepresentationInterface{
	
	private EntityMouvementSequenceur rmv;
	private EntityArtefactInit ArtefactInit;
	private EntityArtefactFeature ArtefactFeature;
	
	public EntityArtefact(String name, SimFeatures features) {
		super(name, features);
		ArtefactFeature = (EntityArtefactFeature) features;
	}

	@Override
	public void onParentSet() {
		
	}

	@Override
	protected void initializeSimEntity(SimInitParameters init) {
		ArtefactInit = (EntityArtefactInit) getInitParameters();

		rmv = (EntityMouvementSequenceur_Exemple) createChild(EntityMouvementSequenceur_Exemple.class, "monSequenceur", ((EntityArtefactFeature) getFeatures()).getSeqFeature());
		rmv.initialize(ArtefactInit.getMvtSeqInitial());
	
	}

	@Override
	protected void BeforeActivating(IEntity sender, boolean starting) {
		
	}

	@Override
	protected void AfterActivate(IEntity sender, boolean starting) {
		Logger.Detail(this, "AfterActivate", Messages.ActivationArtefact);
		rmv.activate();
	}
	

	@ToRecord(name="Position")
	@Override
	public Point3D getPosition() {
		return rmv.getPosition(getCurrentLogicalDate());
	}

	

	@Override
	protected void BeforeDeactivating(IEntity sender, boolean starting) {
		rmv.deactivate();
	}

	@Override
	protected void AfterDeactivated(IEntity sender, boolean starting) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void AfterTerminated(IEntity sender, boolean restart) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Color getColor() {
		return ArtefactFeature.getCouleur();
	}

	//60% des artefacts sont des spheres rouges, 30% sont des cylindres jaunes, 10% sont des boites cubiques vertes
	@Override
	public double getFormat() {
		return ArtefactFeature.getRayon();
	}

}
