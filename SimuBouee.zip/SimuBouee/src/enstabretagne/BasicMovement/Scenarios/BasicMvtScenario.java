package enstabretagne.BasicMovement.Scenarios;

import java.util.Map;

import enstabretagne.base.logger.Logger;
import enstabretagne.base.time.LogicalDateTime;
import enstabretagne.simulation.components.IEntity;
import enstabretagne.simulation.components.ScenarioId;
import enstabretagne.simulation.components.data.SimFeatures;
import enstabretagne.simulation.components.data.SimInitParameters;
import enstabretagne.simulation.components.implementation.SimEntity;
import enstabretagne.simulation.components.implementation.SimScenario;
import enstabretagne.simulation.core.implementation.SimEvent;
import enstabretagne.BasicMovement.SimEntity.Bouee.Bouee;
import enstabretagne.BasicMovement.SimEntity.Bouee.BoueeFeatures;
import enstabretagne.BasicMovement.SimEntity.Bouee.BoueeInit;
import enstabretagne.BasicMovement.SimEntity.Navire.EntityNavire;
import enstabretagne.BasicMovement.SimEntity.Navire.EntityNavireFeature;
import enstabretagne.BasicMovement.SimEntity.Navire.EntityNavireInit;
import enstabretagne.BasicMovement.SimEntity.Ocean.EntityOcean;
import enstabretagne.BasicMovement.SimEntity.Ocean.EntityOceanFeature;
import enstabretagne.BasicMovement.SimEntity.Ocean.EntityOceanInit;
import enstabretagne.BasicMovement.base.messages.Messages;

public class BasicMvtScenario extends SimScenario{

	public BasicMvtScenario(ScenarioId id, SimFeatures features, LogicalDateTime start, LogicalDateTime end) {
		super(id, features, start, end);
		
	}
	
	@Override
	protected void initializeSimEntity(SimInitParameters init) {
		super.initializeSimEntity(init);
	}
	
	@Override
	protected void AfterActivate(IEntity sender, boolean starting) {
		super.AfterActivate(sender, starting);
		
		BasicMvtScenarioFeatures feature = (BasicMvtScenarioFeatures) getFeatures();
		Logger.Detail(this, "afteractivate", Messages.TailleListeBouee, feature.getBouees().size());

		for(Map.Entry<BoueeFeatures, BoueeInit> e : feature.getBouees().entrySet())
		{
			Logger.Detail(this, "afteractivate", Messages.BoueeCree, e.getValue(),e.getKey());
			Post(new BoueeArrival(e.getValue(),e.getKey()));
		}
		for(Map.Entry<EntityNavireFeature, EntityNavireInit> e : feature.getNavires().entrySet())
		{
			Logger.Detail(this, "afteractivate", Messages.NavireCree, e.getValue(),e.getKey());
			Post(new NavireArrival(e.getValue(),e.getKey()));
		}
		for(Map.Entry<EntityOceanFeature, EntityOceanInit> e : feature.getOcean().entrySet())
		{
			Logger.Detail(this, "afteractivate", Messages.NavireCree, e.getValue(),e.getKey());
			Post(new OceanArrival(e.getValue(),e.getKey()));
		}
	}
	
	class BoueeArrival extends SimEvent
	{
		private BoueeInit i;
		private BoueeFeatures f;
		public BoueeInit getI() {
			return i;
		}
		
		public BoueeFeatures getF() {
			return f;
		}
		
		
		public BoueeArrival(BoueeInit i, BoueeFeatures f) {
			this.i=i;
			this.f=f;
		}

		@Override
		public void Process() {
			Logger.Detail(this, "BoueeArrival.Process", Messages.CreationBaie + i);
			SimEntity b = createChild(Bouee.class, i.getName() , f);
			b.initialize(getI());
			b.activate();
		}
		
	}

	class NavireArrival extends SimEvent
	{
		private EntityNavireInit i;
		private EntityNavireFeature f;
		
		public EntityNavireInit getI() {
			return i;
		}
		
		public EntityNavireFeature getF() {
			return f;
		}
		
		
		public NavireArrival(EntityNavireInit i, EntityNavireFeature f) {
			this.i=i;
			this.f=f;
		}

		@Override
		public void Process() {
			Logger.Detail(this, "NavireArrival.Process", Messages.CreationNavire + i);
			SimEntity b = createChild(EntityNavire.class, i.getName() , f);
			b.initialize(getI());
			b.activate();
		}
		
	}

	class OceanArrival extends SimEvent
	{
		private EntityOceanInit i;
		private EntityOceanFeature f;
		
		public EntityOceanInit getI() {
			return i;
		}
		
		public EntityOceanFeature getF() {
			return f;
		}
		
		
		public OceanArrival(EntityOceanInit i, EntityOceanFeature f) {
			this.i=i;
			this.f=f;
		}

		@Override
		public void Process() {
			Logger.Detail(this, "OceanArrival.Process", Messages.CreationOcean + i);
			SimEntity b = createChild(EntityOcean.class, i.getName() , f);
			b.initialize(getI());
			b.activate();
		}
		
	}
}


public class SalonCoiffureScenario extends SimScenario {
	

	/** The random. */
	MoreRandom random;
	
	/** The lambda arrivee client. */
	double lambda_arrivee_client; 
	
	/** The start client arrival. */
	LogicalDuration startClientArrival;
	
	/** The end client arrival. */
	LogicalDuration endClientArrival;

	/** The arrival delay recording cat gen. */
	CategoriesGenerator arrivalDelayRecordingCatGen;
	
	/** The delai attente recording cat gen. */
	CategoriesGenerator delaiAttenteRecordingCatGen;
	
	/**
	 * Instantiates a new salon coiffure scenario.
	 *
	 * @param scenarioId the scenario id
	 * @param features the features
	 * @param start the start
	 * @param end the end
	 */
	public SalonCoiffureScenario(
			ScenarioId scenarioId, 
			SimFeatures features,LogicalDateTime start, LogicalDateTime end) {
		super(scenarioId, features,start,end);
		SalonCoiffureScenarioFeatures scsf = (SalonCoiffureScenarioFeatures) features;

		arrivalDelayRecordingCatGen = scsf.getArrivalDelayRecordingCatGen();
		delaiAttenteRecordingCatGen=scsf.getDelaiAttenteRecordingCatGen();

		random = new MoreRandom(MoreRandom.globalSeed);
		lambda_arrivee_client = scsf.getFrequenceArriveeClientParHeure()/3600;
		startClientArrival = LogicalDuration.fromString(scsf.getDebutArriveeClient());
		endClientArrival = LogicalDuration.fromString(scsf.getFinArriveeClient());
		
		
	}
	
	/* (non-Javadoc)
	 * @see enstabretagne.simulation.components.implementation.SimScenario#initializeSimEntity(enstabretagne.simulation.components.data.SimInitParameters)
	 */
	@Override
	protected void initializeSimEntity(SimInitParameters init) {
		super.initializeSimEntity(init);
		SalonCoiffureScenarioFeatures scsf =(SalonCoiffureScenarioFeatures) getFeatures();
		SimEntity e=createChild(Salon.class,scsf.getId(), scsf.getSalonFeatures());
		
		e.initialize(scsf.getSalonInit());
		
	}

	
	
	/** The nb client. */
	int nbClient;

	/**
	 * The Class DebutArriveeClient.
	 */
	class DebutArriveeClient extends SimEvent {

		/* (non-Javadoc)
		 * @see enstabretagne.simulation.core.ISimEvent#Process()
		 */
		@Override
		public void Process() {
			LogicalDateTime d = getNextTimeForClient();
			if(d!=null) Post(new NouveauClientEvent(),d);
			
			Post(new FinArriveeClient(),getCurrentLogicalDate().truncateToDays().add(endClientArrival));			
			Logger.Information(this.Owner(), "DebutArriveeClient", Messages.OuverturePeriodeNouveauxClients);
		}


	}

	/**
	 * The Class FinArriveeClient.
	 */
	class FinArriveeClient extends SimEvent {
		
		/* (non-Javadoc)
		 * @see enstabretagne.simulation.core.ISimEvent#Process()
		 */
		@Override
		public void Process() {			
			Post(new DebutArriveeClient(),getCurrentLogicalDate().truncateToDays().add(LogicalDuration.ofDay(1).add(startClientArrival)));			
			Logger.Information(this.Owner(), "FinArriveeClient", Messages.FinPeriodeNouveauxClients);
		}		
	}

	/**
	 * The Class NouveauClientEvent.
	 */
	class NouveauClientEvent extends SimEvent {


		/** The duree next client. */
		int dureeNextClient;
		
		/* (non-Javadoc)
		 * @see enstabretagne.simulation.core.ISimEvent#Process()
		 */
		@Override
		public void Process() {
			double clientAvecFavoriProba=random.nextDouble()*10;
			ClientFeatures cf ;

			if(clientAvecFavoriProba<=4){
				double typeClientProba=random.nextDouble()*4;
				if(typeClientProba<=3)
					cf=new ClientFeatures("Client_"+nbClient++,CoiffeursNames.Lumpy,CoiffeursNames.Petunia,3);
				else
					cf=new ClientFeatures("Client_"+nbClient++,CoiffeursNames.Flaky,CoiffeursNames.Petunia,3);
			}
			else
			{
				cf=new ClientFeatures("Client_"+nbClient++,CoiffeursNames.Indifferent,CoiffeursNames.Petunia,6);
			}
			Client c=(Client)createChild(Client.class, cf.getId(), cf);
			
			c.initialize(new ClientInit(delaiAttenteRecordingCatGen));
			Logger.Information(this.Owner(), "NouveauClient", Messages.NouveauClientPotentiel,cf.getId());
			LogicalDateTime d = getNextTimeForClient();
			if(d!=null) Post(new NouveauClientEvent(),d);

			c.activate();
			
		}
		
		
	}

	
	/**
	 * The Class VerifDistribRecord.
	 */
	private class VerifDistribRecord implements IRecordable{
		
		/** The d. */
		double d;
		
		/**
		 * Instantiates a new verif distrib record.
		 *
		 * @param d the d
		 */
		public VerifDistribRecord(double d){
		this.d=d;
	}
		
		/* (non-Javadoc)
		 * @see enstabretagne.base.logger.IRecordable#getTitles()
		 */
		@Override
		public String[] getTitles() {
			return new String[]{"delta","Categorie"};
		}
		
		/* (non-Javadoc)
		 * @see enstabretagne.base.logger.IRecordable#getRecords()
		 */
		@Override
		public String[] getRecords() {
			arrivalDelayRecordingCatGen.getSegmentOf(d).toString();
			return new String[]{Double.toString(d/60),arrivalDelayRecordingCatGen.getSegmentOf(d/60).toString()};
		}
		
		/* (non-Javadoc)
		 * @see enstabretagne.base.logger.IRecordable#getClassement()
		 */
		@Override
		public String getClassement() {
			return "NextClient";
		}
		
	}
	
	/**
	 * Gets the next time for client.
	 *
	 * @return the next time for client
	 */
	LogicalDateTime getNextTimeForClient() {
		
		double d=random.nextExp(lambda_arrivee_client);
		Logger.Data(new VerifDistribRecord(d));

		LogicalDuration t = LogicalDuration.ofSeconds(d);
		LogicalDateTime nextEndOfClientsArrival =getCurrentLogicalDate().truncateToDays().add(endClientArrival); 

		LogicalDateTime possibleClientArrival = getCurrentLogicalDate().add(t);
		if(possibleClientArrival.compareTo(nextEndOfClientsArrival)<0)
			return possibleClientArrival;
		else
			return null;

	}
	
	/* (non-Javadoc)
	 * @see enstabretagne.simulation.components.implementation.SimScenario#AfterActivate(enstabretagne.simulation.components.IEntity, boolean)
	 */
	@Override
	protected void AfterActivate(IEntity sender, boolean starting) {
		super.AfterActivate(sender, starting);
		
		this.Post(new DebutArriveeClient());
	}
}


