package enstabretagne.BasicMovement.Scenarios;

import java.util.HashMap;

import enstabretagne.simulation.components.data.SimFeatures;
import enstabretagne.BasicMovement.SimEntity.Bouee.BoueeFeatures;
import enstabretagne.BasicMovement.SimEntity.Bouee.BoueeInit;
import enstabretagne.BasicMovement.SimEntity.Navire.EntityNavireFeature;
import enstabretagne.BasicMovement.SimEntity.Navire.EntityNavireInit;
import enstabretagne.BasicMovement.SimEntity.Ocean.EntityOceanFeature;
import enstabretagne.BasicMovement.SimEntity.Ocean.EntityOceanInit;

public class BasicMvtScenarioFeatures extends SimFeatures {

	private HashMap<BoueeFeatures, BoueeInit> bouees;
	private HashMap<EntityNavireFeature, EntityNavireInit> navires;
	private HashMap<EntityOceanFeature,EntityOceanInit> ocean;
	
	public HashMap<EntityOceanFeature, EntityOceanInit> getOcean() {
		return ocean;
	}
	public HashMap<EntityNavireFeature, EntityNavireInit> getNavires() {
		return navires;
	}
	
	public HashMap<BoueeFeatures, BoueeInit> getBouees() {
		return bouees;
	}
	public BasicMvtScenarioFeatures(String id) {
		super(id);
		bouees = new HashMap<>();
		navires = new HashMap<>();
		ocean = new HashMap<>();
	}	

}
