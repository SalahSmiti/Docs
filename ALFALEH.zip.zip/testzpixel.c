#include <stdio.h>
#include <stdlib.h>
#include "zpixel.h"

void testCreatePixel()
{
    struct zpixel * zP = createZpixel(0,0,2);
    printf("test [01] [creation d'un zPixel]\n");
    printf("input : x = 0, y = 0, taille = 2\n");
    printf("expected output :  x=0, y=0, taille=2\n");
    printf("output : x : %d, y : %d, taille :%d\n",zP->pos.x, zP->pos.y, zP->taille);
    printf("--------------------------------------\n");
}

void testzPixelInit()
{
    struct zpixel * zP = createZpixel(0,0,2);
    zPixelInit(zP,15,25,220);
    printf("test [02] [initialisation zPixel en couleur]\n");
    printf("input : zP,150,25,220\n");
    printf("expected output : r=150,g=25,b=220 \n");
    printf("output : r : %d, g : %d, b :%d\n",zP->color.r, zP->color.g, zP->color.b);
    printf("--------------------------------------\n");
}

void testPixelInitBlack()
{
    struct zpixel * zP = createZpixel(0,0,2);
    printf("test [013] [initialisation zPixel en noir]\n");
    printf("input : zPixel * zP\n");
    printf("expected output : r=0,g=0,b=0 \n");
    printf("output : r : %d, g : %d, b :%d\n",zP->color.r, zP->color.g, zP->color.b);
    printf("--------------------------------------\n");
}



void testPixelInitWhite()
{
    struct zpixel * zP = createZpixel(0,0,2);
    printf("test [013] [initialisation zPixel en blanc]\n");
    printf("input : zPixel * zP\n");
    printf("expected output : r=255,g=255,b=255 \n");
    printf("output : r : %d, g : %d, b :%d\n",zP->color.r, zP->color.g, zP->color.b);
    printf("--------------------------------------\n");
}


int main()
{  
    testCreatePixel();
    return 0;
}
