#include <stdio.h>
#include <zpixel.h>
#include <math.h>
#include <stdlib.h>
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))



//gcc fib.c -lm -o fibo


/* ---------------------------------------------------
 * Question 1
 * ---------------------------------------------------
*/

struct zpixel *createZpixel( int x , int y , int taille)
{
    struct zpixel *zP;  // on declare le pointeur
    zP = (struct zP *)malloc(sizeof(struct zP *));
    zP->taille = taille;
    zP->pos.x = x;
    zP->pos.y = y;

    return zP;
}
 
/* ---------------------------------------------------
 * Question 2
 * ---------------------------------------------------
 */

double GetLightness(struct zpixel *zp)
{
	int min = MIN(MIN(zp->color.r, zp->color.g),zp->color.b);
	int max = MAX(MAX(zp->color.r, zp->color.g),zp->color.b);
	return (min + max)/2;
}

double GetSaturation(struct zpixel *zp)
{
	double lightness = GetLightness(zp);
	int min = MIN(MIN(zp->color.r, zp->color.g),zp->color.b);
	int max = MAX(MAX(zp->color.r, zp->color.g),zp->color.b);
	if(lightness < 128)
		return (max - min)/(min + max) * 255;
	return (max - min)/(511 - min - max) * 255;
}

/* ---------------------------------------------------
 * Question 3
 * ---------------------------------------------------
 */
double GetDistance(struct zpixel *zp1,struct zpixel *zp2)
{
	return sqrt(
	pow(zp1->color.r - zp2->color.r,2) + pow(zp1->color.g - zp2->color.g,2) + pow(zp1->color.b - zp2->color.b,2) 
	);
}

/* ---------------------------------------------------
 * Question 4
 * ---------------------------------------------------
*/
struct image *createImage( int width, int height, int rowstride, unsigned char * pixelBuffer)
{
    struct image *img; 
    img = (struct img *)malloc(sizeof(struct img *));
    img->width = width;
    img->height = height;
    img->rowstride = rowstride;
    img->pixelBuffer = pixelBuffer;
    return img;
}


void zpixelProjection(struct image *img,struct zpixel *zp)
{
 
}



int main() {
  struct zpixel  * zP = createZpixel(0,0,2);
    printf("test [013] [initialisation zPixel en blanc]\n");
    printf("input : zPixel * zP\n");
    printf("expected output : r=255,g=255,b=255 \n");
    printf("output : r : %d, g : %d, b :%d\n",zP->color.r, zP->color.g, zP->color.b);
    printf("--------------------------------------\n");
  return 1;
}






