struct zpixel 
{
    int taille ; 
    struct pos {
        int x,y ; 
    }pos;


    struct color {
        int r,g,b ; 
    }color; 

    double degradation ; 
};

typedef struct zpixel zPixel;


zPixel *createZPixel(int x, int y, int taille);
void zPixelInit(zPixel *zP, int r, int g, int b);
void zPixelInitBlack(zPixel *zP);
void zPixelInitWhite(zPixel *zP);
double GetDistance(zpixel *zp1,zpixel *zp1);
double GetSaturation(zpixel *zp);
double GetLightness(zpixel *zp);
