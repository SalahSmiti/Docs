// Exercice 3

#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <sys/types.h>

int main()
{

  int code_retour ;
code_retour = fork ();
switch (code_retour ) {
 case –1 :
 printf (“Pbm lors de la creation du processus\n”);
 break;
 case 0 :
 sleep(5);
 printf (“Je suis le processus fils \n”);
 pid_t pid = getpid();
 printf("Fils pid: %lun", pid);
 	char cwd[PATH_MAX];
   if (getcwd(cwd, sizeof(cwd)) != NULL) {
       printf("Current working dir: %s\n", cwd);
   }
   
   printf(“Get the real user ID:%\n”, getuid());
printf(“Get the effective user ID:%\n”, geteuid());
printf(“Get the real group ID:%\n”, getgid());
printf(“Get the effective group ID:%\n”, getegid());
 break;
 default :
 printf (“Je suis le processus père\n”);
 printf (“Je viens de créer le processus fils dont le pid est %d \n”,code_retour);
 pid_t pid = getpid();
 printf("Père pid: %lun", pid);
 	char cwd[PATH_MAX];
   if (getcwd(cwd, sizeof(cwd)) != NULL) {
       printf("Current working dir: %s\n", cwd);
   }
   
   printf(“Get the real user ID:%\n”, getuid());
printf(“Get the effective user ID:%\n”, geteuid());
printf(“Get the real group ID:%\n”, getgid());
printf(“Get the effective group ID:%\n”, getegid());
 break;
}
}
