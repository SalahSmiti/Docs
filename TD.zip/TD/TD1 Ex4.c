// Exercice 4

#define _POSIX_SOURCE
#include <fcntl.h>
#include <limits.h>
#include <sys⁄types.h>
#include <sys⁄stat.h>
#include <unistd.h>
#undef _POSIX_SOURCE
#include <stdio.h>

int main() {
        FILE * fp;
        fp = fopen("toto.txt", "w+");
        fputs("abcefghijklmnoprstuvwxyz,", fp);
        fputs("We don't need to use for loop\n", fp);
        fputs("Easier than fputc function\n", fp);
        fclose(fp);
        return (0);
    }
	
	


main() {
  char fn[]="creat.file", text[]="This is a test";
  int fd;

  if ((fd = creat(fn, S_IRUSR | S_IWUSR)) < 0)
    perror("creat() error");
  else {
    write(fd, text, strlen(text));
    close(fd);
    unlink(fn);
  }
return(fd);
}
int main()
{
	FILE * fp;
    fp = fopen("toto.txt", "w+");
    fputs("abcefghijklmnoprstuvwxyz,", fp);

   int code_retour ;
   code_retour = fork ();
	switch (code_retour ) 
	{
		 case –1 :
			printf (“Pbm lors de la creation du processus\n”);
		 break;
		 case 0 :
		    fp = fopen("toto.txt", "w+");
			fputs("Fils,", fp);
			sleep(2);

		 break;
		 default :
			printf (“Je suis le processus père\n”);
			sleep(1);
			fp = fopen("toto.txt", "w+");
			fputs("Fils,", fp);
			sleep(2);
		 break;
	}
}
