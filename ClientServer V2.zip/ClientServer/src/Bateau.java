
public class Bateau 
{
	int immatriculation = 0;
	double positionX = 0.0;
	double positionY = 0.0;
	String modele = "";
	int vitesseMax = 0;
	boolean peutStationner = false;
	
}
