import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class MessageTranslator 
{
	
	User AccepterNouveauClient(DataOutputStream dout,DataInputStream din,
			BufferedReader br, String str3)
	{

		User newUser = new User();
		try 
        {
        str3 = "Veuillez saisir le nom \n";
        dout.writeUTF(str3);
        str3=din.readUTF();
        newUser.nom = str3;
        
        str3 = "Veuillez saisir le mail \n";
        dout.writeUTF(str3);
        str3=din.readUTF();
        newUser.email = str3;
        
        str3 = "Veuillez saisir le IBAN \n";
        dout.writeUTF(str3);
        str3=din.readUTF();
        newUser.iban = str3;
        
        
        
        System.out.println("client says : "+str3);
        
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return newUser;
	}
}
