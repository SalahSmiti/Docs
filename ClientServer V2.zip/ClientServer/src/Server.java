import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server 
{
	 public static void main(String args[]) throws Exception
	 {
		 // Nous devons enregistrer tout les donn�es du jeu ici
		 ContextHandler contextHandler = new ContextHandler();
		 MessageTranslator mt = new MessageTranslator();
	     ServerSocket ss=new ServerSocket(3333);
	     Socket s=ss.accept();
	     // attendre un input => doit �tre appel� qu'au besoin
	     //DataInputStream din=new DataInputStream(s.getInputStream());
	     DataInputStream din;
	     DataOutputStream dout=new DataOutputStream(s.getOutputStream());
	     BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	     String str="",str2="",str3="";
	     str3 = ShowMenu(dout, str3);
	        
	     while(!str.equals("stop"))
	     {
	     	din=new DataInputStream(s.getInputStream());
	        str=din.readUTF();
	        System.out.println("client says : "+str);
	        
	        if(str.equals("1"))
	        {
	          	User newUser = mt.AccepterNouveauClient(dout,din,br,str3);
	          	contextHandler.usersList.add(newUser);
	        }
	        /// ...
	        if(str.equals("2"))
	        {
	          	break;
	        }
	        str2=br.readLine();
	        dout.writeUTF(str2);
	        dout.flush();
	     }
	     //din.close();
	     s.close();
	     ss.close();
	    }

	private static String ShowMenu(DataOutputStream dout, String str3) throws IOException {
		str3 += "1 : Ajouter un nouveau Ustilisateur \n";
	     str3 += "2 : Sortir \n";
	     // On envoie �a au client => c'est lui qui doit l'afficher
         dout.writeUTF(str3);
         dout.flush();
		return str3;
	}
}
