
public class User 
{
	int immatriculation = 0;
	String nom = "";
	String email = "";
	String iban = "";
	String adresse = "";
	int telephone = 0;
}
