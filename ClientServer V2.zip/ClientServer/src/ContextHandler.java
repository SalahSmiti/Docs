import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ContextHandler 
{
	List<User> usersList = new ArrayList<>();
	List<Bateau> bateauxList = new ArrayList<>();
	
	Map<String, String> mapUserBateau = new HashMap<String, String>();
	//map.put("dog", "type of animal");
	//System.out.println(map.get("dog"));

}
