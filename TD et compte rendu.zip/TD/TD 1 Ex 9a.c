#include  <stdio.h>
#include  <stdlib.h>
#include  <sys/types.h>
#include  <unistd.h>
#include <sys/wait.h>


int WithExecl()
{
	pid_t child_pid;
  /* Duplique ce processus. */
  child_pid = fork ();
  if (child_pid != 0)
     /* Nous sommes dans le processus parent. */
     return child_pid;
  else 
  {
	execl("/bin/ps", "ps", "-l", (char *)0);
    fprintf (stderr, "une erreur est survenue au sein de execl\n");
    abort ();
  }
	return 0;
}



int WithExecv ()
{
    int status;

  char* arg_list[] = {
     "/bin/ps",   
     "-l"
  };

    if ( fork() == 0 )
        execv( arg_list[0], arg_list ); // child: call execv with the path and the args
    else
        wait( &status );        // parent: wait for the child (not really necessary)
	return status;
}
int main ()
{
  WithExecl();
  WithExecv();
  printf ("Fin du programme principal\n");
  return 0;
}