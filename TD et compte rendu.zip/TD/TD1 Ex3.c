#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <sys/types.h>

int main()
{
char cwd[PATH_MAX];
int code_retour, pid ;
code_retour = fork ();
switch (code_retour ) {
 case -1 :
 printf ("Pbm lors de la creation du processus\n");
 break;
 case 0 :
 sleep(5);
 printf ("Je suis le processus fils \n");
 pid = getpid();
 printf("Fils pid: %d", pid);
   if (getcwd(cwd, sizeof(cwd)) != NULL) {
       printf("Current working dir: %s\n", cwd);
   }
   
printf("Get the real user ID:%d\n", getuid());
printf("Get the effective user ID:%d\n", geteuid());
printf("Get the real group ID:%d\n", getgid());
printf("Get the effective group ID:%d\n", getegid());
 break;
 default :
 printf ("Je suis le processus père\n");
 printf ("Je viens de créer le processus fils dont le pid est %d \n",code_retour);
 pid = getpid();
 printf("Père pid: %d", pid);
   if (getcwd(cwd, sizeof(cwd)) != NULL) {
       printf("Current working dir: %s\n", cwd);
   }
   
printf("Get the real user ID:%d\n", getuid());
printf("Get the effective user ID:%d\n", geteuid());
printf("Get the real group ID:%d\n", getgid());
printf("Get the effective group ID:%d\n", getegid());
 break;
}
}
