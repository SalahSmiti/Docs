package enstabretagne.BasicMovement.base.messages;

// TODO: Auto-generated Javadoc
/**
 * The Class Messages.
 */
public class Messages {
	
	/** The Constant TailleListeBouee. */
	public static final String TailleListeBouee = "taille liste bouees = %s";
	
	/** The Constant BoueeCree. */
	public static final String BoueeCree = "bouee � cr�er = %s , %s"; 
	
	/** The Constant NavireCree. */
	public static final String NavireCree = "navire � cr�er = %s , %s";
	
	/** The Constant CreationBaie. */
	public static final String CreationBaie = "Cr�ation de la baie " ;
	
	/** The Constant CreationNavire. */
	public static final String CreationNavire = "Cr�ation du Navire";
	
	/** The Constant CreationOcean. */
	public static final String CreationOcean = "Cr�ation de l'oc�an";
	
	/** The Constant ActivationBouee. */
	public static final String ActivationBouee = "Activation de la bou�e %s";
	
	/** The Constant ActivationSequenceur. */
	public static final String ActivationSequenceur = "Activation de MouvementSequenceur";
	
	/** The Constant ActivationNavire. */
	public static final String ActivationNavire = "Activation de Navire";
	
	/** The Constant ActivationOcean. */
	public static final String ActivationOcean = "Activation de Ocean";
	
		/** The Constant CubeNoirTrouve. */
	public static final String CubeNoirTrouve = "Cube noir trouv� ";
}

