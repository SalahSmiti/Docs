package engine;

public interface ISimEntity {

}
