package enstabretagne.BasicMovement.SimEntity.Artefact;

import enstabretagne.simulation.components.data.SimFeatures;
import enstabretagne.BasicMovement.SimEntity.MouvementSequenceur.EntityMouvementSequenceurFeature;
import javafx.scene.paint.Color;

public class EntityArtefactFeature extends SimFeatures {
	private Color couleur;
	private String format;
	
	private EntityMouvementSequenceurFeature seq;
	
	public EntityArtefactFeature(String id,String format,Color couleur,EntityMouvementSequenceurFeature seq) {
		super(id);
		this.format = format;
		this.couleur = couleur;
		this.seq=seq;

	}

	public Color getCouleur() {
		return couleur;
	}
	
	public String getformat() {
		return format;
	}

	public EntityMouvementSequenceurFeature getSeqFeature() {
		return seq;
	}

}
