package enstabretagne.BasicMovement.SimEntity.Ocean.Representation3D;

import enstabretagne.monitor.interfaces.IMovable;

public interface EntityOcean3DRepresentationInterface extends IMovable{
	
}