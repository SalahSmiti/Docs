package enstabretagne.BasicMovement.SimEntity.MouvementSequenceur;

import enstabretagne.simulation.components.data.SimFeatures;

public class EntityMouvementSequenceurFeature extends SimFeatures {

	
	public EntityMouvementSequenceurFeature(String id) {
		super(id);
	}

}
