struct image 
{
    int width,height;
	int rowstride;
	unsigned char * pixelBuffer;
 
};

